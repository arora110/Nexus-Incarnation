﻿using UnityEngine;
using System.Collections;

public class cube02 : MonoBehaviour {

	public float moveSpeed;
	private bool onGround;
	private float jumpPower;
	public float dashSpeed;
	public GameObject shield;
	public float shieldTime;

	// Use this for initialization
	void Start () {
		shield = GameObject.FindGameObjectWithTag("shield");
		shield.active = false;
		if (moveSpeed == 0) {
			moveSpeed = 7;
		}
		if (dashSpeed == 0) {
			dashSpeed = 7;
		}
		if (shieldTime == 0) {
			shieldTime = 5;
		}
	}
	
	// Update is called once per frame
	void Update () {
		//Basic AWSD character movement
		var x = Input.GetAxis("Horizontal") * moveSpeed * Time.deltaTime;
		var z = Input.GetAxis ("Vertical") * moveSpeed * Time.deltaTime;
		Vector3 temp = transform.position;
		transform.Translate(x, 0f, z);
		//Triggers Shield
		if (Input.GetKey (KeyCode.R)) {
			activateShield ();
		}
		//Triggers Dash
		float step = dashSpeed * Time.deltaTime;
		if (Input.GetKey (KeyCode.A)) {
			if (Input.GetKey (KeyCode.F)) {
				temp.x -= 10;
				transform.position = Vector3.MoveTowards (transform.position, temp, step);
			}
		} else if (Input.GetKey (KeyCode.W)) {
			if (Input.GetKey (KeyCode.F)) {
				temp.z += 10;
				transform.position = Vector3.MoveTowards (transform.position, temp, step);
			}
		} else if (Input.GetKey (KeyCode.D)) {
			if (Input.GetKey (KeyCode.F)) {
				temp.x += 10;
				transform.position = Vector3.MoveTowards (transform.position, temp, step);
			}
		} else if (Input.GetKey (KeyCode.S)) {
			if (Input.GetKey (KeyCode.F)) {
				temp.z -= 10;
				transform.position = Vector3.MoveTowards (transform.position, temp, step);
			}
		} 
	}

	//Triggers Shield Method
	public void activateShield() {
		shield.active = true;
		StartCoroutine(ExecuteAfterTime(shieldTime));
	}
	//Helper method for activateShield
	IEnumerator ExecuteAfterTime(float time)
	{
		yield return new WaitForSeconds(time);
		shield.active = false;
	}
}